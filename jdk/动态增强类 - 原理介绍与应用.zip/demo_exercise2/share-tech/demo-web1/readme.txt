

javaagent 方式：
    java-agent1:
        -javaagent:E:\ucarinc_workspace\self\demo_exercise2\share-tech\java-agent1\target\java-agent1-jar-with-dependencies.jar=param1=val1;param2=val2



attach 方式：
    java-agent1:
        见 工程 java-attach1 里面的 main方法


jvm-sandbox方式：









