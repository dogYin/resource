


-Xms128M -Xmx128M -Xnoclassgc -ea -Xbootclasspath/a:D:\Program Files\Java\jdk1.8.0_191\lib\tools.jar

    java %s -jar '%s/sandbox-core.jar' %d '%s/sandbox-agent.jar' '%s'
    javaHome, jvmOpts, sandboxLibPath, pid, sandboxLibPath, sandboxAttachArgs




