

使用方式:
    agent方式:
        在目标应用 启动参数加入:
            -javaagent:E:\ucarinc_workspace\self\demo_exercise2\share-tech\java-agent1\target\java-agent1-jar-with-dependencies.jar=param1=val1;param2=val2


